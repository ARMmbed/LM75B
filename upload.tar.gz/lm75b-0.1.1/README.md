LM75B Temperature Sensor Module
